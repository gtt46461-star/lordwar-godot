#if UNITY_5_3_OR_NEWER
using System; using UnityEngine; using LordWar.Data; using LordWar.Simulation; using LordWar.AI;
namespace LordWar.UnityRuntime {
    public sealed class LordWarBootstrap : MonoBehaviour {
        public static GameWorld World; public int seed=0; public int width=160,height=160,kingdoms=2; public AiDifficulty computerDifficulty=AiDifficulty.Hard; static GameDataCatalog _data; static LordWarBootstrap _instance;
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)] static void Ensure(){if(Object.FindObjectOfType<LordWarBootstrap>()!=null)return;var go=new GameObject("领主战争_运行核心");DontDestroyOnLoad(go);go.AddComponent<LordWarBootstrap>();go.AddComponent<ChineseHud>();go.AddComponent<WorldCameraController>();}
        void Awake(){_instance=this;Application.targetFrameRate=60;CreateFreshWorld(seed==0?NewSeed():seed,width,height,kingdoms,computerDifficulty);}
        static int NewSeed(){unchecked{return (int)(DateTime.UtcNow.Ticks^(long)Environment.TickCount);}}
        public static void CreateFreshWorld(){if(_instance!=null)_instance.CreateFreshWorld(NewSeed(),_instance.width,_instance.height,_instance.kingdoms,_instance.computerDifficulty);}
        public static void CreateConfiguredWorld(int requestedSeed,int requestedWidth,int requestedHeight,int requestedKingdoms,AiDifficulty difficulty){if(_instance==null)return;int actualSeed=requestedSeed==0?NewSeed():requestedSeed;_instance.CreateFreshWorld(actualSeed,requestedWidth,requestedHeight,requestedKingdoms,difficulty);}
        void CreateFreshWorld(int actualSeed,int requestedWidth,int requestedHeight,int requestedKingdoms,AiDifficulty difficulty){width=Math.Max(72,Math.Min(192,requestedWidth));height=Math.Max(72,Math.Min(192,requestedHeight));kingdoms=Math.Max(2,Math.Min(4,requestedKingdoms));computerDifficulty=difficulty;if(_data==null){_data=new GameDataCatalog();_data.LoadAll(new UnityDataProvider());}World=new GameWorld(actualSeed,_data,computerDifficulty);World.CreateNewWorld(width,height,kingdoms);WorldRenderer old=GetComponent<WorldRenderer>();if(old!=null)Destroy(old);var r=gameObject.AddComponent<WorldRenderer>();r.Bind(World);}
        void Update(){if(World!=null)World.Tick(Time.unscaledDeltaTime);}
    }
}
#endif
