#!/usr/bin/env python3
"""Apply conservative, explicitly whitelisted same-purpose substitutions for V9 art gaps.
No missing row is converted unless a rule documents why the source has the same in-game role.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,re,shutil
from pathlib import Path
from collections import Counter

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--project',default=str(Path(__file__).resolve().parents[1]));ap.add_argument('--source-root',required=True);a=ap.parse_args()
 P=Path(a.project);S=Path(a.source_root);E=P/'Evidence';D=P/'Assets/Resources/LordWarArt/恢复_同源替代';D.mkdir(parents=True,exist_ok=True)
 rows=list(csv.DictReader(open(E/'ASSET_RESOLUTION.csv',encoding='utf-8-sig')))
 physical=[]
 for p in S.rglob('*.png'):
  physical.append(p)
 def pick_name_contains(parts,prefer_sprite=True):
  parts=[x.lower() for x in parts]
  c=[p for p in physical if all(x in p.name.lower() for x in parts)]
  if prefer_sprite:
   cs=[p for p in c if '/Sprites/' in str(p).replace('\\','/')]
   if cs:c=cs
  c.sort(key=lambda p:(0 if '0.22.21' in str(p) else 1,len(str(p))))
  return c[0] if c else None
 def building_candidate(res):
  # Generic building Texture2D missing -> use the same building's actual first Sprite frame.
  c=[]
  key=res.lower()
  for p in physical:
   n=p.name.lower()
   if n.startswith(key+'#0__') or n.startswith(key+'#0@0__') or n.startswith(key+'#0@1__'):
    c.append(p)
  c.sort(key=lambda p:(0 if '0.22.21' in str(p) else 1,0 if '#0@0' in p.name else 1,len(str(p))))
  return c[0] if c else None
 def numbered_background(kind,res):
  m=re.search(r'(\d+)$',res)
  num=int(m.group(1)) if m else 2
  # Available backgrounds are 02..14. Preserve number where possible, otherwise cycle.
  n=num if 2<=num<=14 else 2+(num%13)
  return pick_name_contains([f'{kind}_background_{n:02d}'])
 records=[]
 building_roots=re.compile(r'^(?:[1-5]?(?:house|hall)_(?:human|dwarf|elf|orc)|house_(?:human|dwarf|elf|orc)|hall_human|barracks_(?:human|dwarf|elf|orc)|docks_(?:human|dwarf|elf|orc)|temple_human|tent_human|flameTower|iceTower|landmine|mine)$',re.I)
 for r in rows:
  if r.get('status')!='missing':continue
  res=r.get('resource',''); candidate=None; reason=''
  if res=='t_grasshopper': candidate=pick_name_contains(['iconGrasshopper']);reason='同物种真实图标替代缺失单位纹理'
  elif res=='t_sandSpider': candidate=pick_name_contains(['iconSandSpider']);reason='同物种真实图标替代缺失单位纹理'
  elif res in ('tree','tree_dead'):
   candidate=pick_name_contains([res+'#']);reason='同一树木资源的真实拆帧替代缺失整图'
  elif building_roots.match(res):
   candidate=building_candidate(res);reason='同一建筑的真实首帧Sprite替代缺失通用Texture2D'
  elif res.startswith('clan_icon_'):
   candidate=numbered_background('clan',res);reason='真实家族背景素材替代缺失家徽图标；运行时仍叠加家族颜色'
  elif res.startswith('alliance_icon-') or res.startswith('alliance_icon_'):
   candidate=numbered_background('alliance',res);reason='真实联盟背景素材替代缺失联盟图标'
  if not candidate or not candidate.exists():continue
  # Keep each expected filename separate so Resources can resolve the desired semantic name.
  out=D/r['expected'];shutil.copy2(candidate,out)
  r['actual']='project/恢复_同源替代/'+r['expected'];r['status']='logical_substitute'
  records.append({'resource':res,'expected':r['expected'],'source':str(candidate.relative_to(S)),'source_sha256':sha(candidate),'output':str(out.relative_to(P)),'output_sha256':sha(out),'reason':reason})
 with open(E/'ASSET_RESOLUTION.csv','w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['resource','expected','actual','status']);w.writeheader();w.writerows(rows)
 counts=Counter(r['status'] for r in rows);pngs=list((P/'Assets/Resources/LordWarArt').rglob('*.png'))
 old=json.load(open(E/'ASSET_IMPORT_REPORT.json',encoding='utf8'))
 old.update({'exact':counts['exact'],'logical_substitute':counts['logical_substitute'],'reconstructed_from_atlas':counts['reconstructed_from_atlas'],'reconstructed_from_known_atlas':counts['reconstructed_from_known_atlas'],'missing':counts['missing'],'resolved_total':len(rows)-counts['missing'],'unique_imported_png':len(pngs),'total_bytes':sum(p.stat().st_size for p in pngs),'missing_sample':[{'resource':r['resource'],'expected':r['expected'],'status':'missing'} for r in rows if r['status']=='missing'][:80]})
 (E/'ASSET_IMPORT_REPORT.json').write_text(json.dumps(old,ensure_ascii=False,indent=2),encoding='utf8')
 (E/'LOGICAL_SUBSTITUTE_PROVENANCE.json').write_text(json.dumps({'applied_this_run':len(records),'items':records},ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({'applied':len(records),'counts':counts,'png_count':len(pngs)},ensure_ascii=False))
if __name__=='__main__':main()
