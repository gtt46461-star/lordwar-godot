#!/usr/bin/env python3
"""Recover V9-mapped sprites that were indexed in Unity manifests but not exported as PNG.

This never labels reconstructed output as an exact extraction.  It uses the Sprite
rect recorded in AssetManifest.csv and crops the matching real Texture2D sheet whose
content GUID/hash is embedded in the expected sprite filename.  Results are marked
`reconstructed_from_atlas` and retain source provenance.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,math,os,re,shutil
from collections import Counter,defaultdict
from pathlib import Path
from PIL import Image

HASH_RE=re.compile(r'__([0-9a-fA-F]{32})__')

def nibble_swap_hash(h):
    h=(h or '').lower()
    return ''.join(pair[1]+pair[0] for pair in re.findall(r'..',h)) if len(h)==32 else ''

def read_csv(p):
    with open(p,encoding='utf-8-sig',errors='ignore',newline='') as f:return list(csv.DictReader(f))

def parse_vec(s):
    if not s:return None
    try:
        vals=[float(x.strip()) for x in s.strip().strip('[]').split(',')]
        return vals
    except Exception:return None

def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--project',default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument('--source-root',required=True,help='Path to 14_全量素材提取')
    a=ap.parse_args()
    project=Path(a.project); source=Path(a.source_root)
    evidence=project/'Evidence'; map_csv=evidence/'ASSET_RESOLUTION.csv'
    art=project/'Assets/Resources/LordWarArt/恢复_图集拆帧'; art.mkdir(parents=True,exist_ok=True)

    versions=[('0.22.21安卓APK',source/'0.22.21安卓APK'),('0.9.0原版',source/'0.9.0原版')]
    manifests={}
    exp_index={}
    texture_by_hash=defaultdict(list)
    for v,root in versions:
        mp=root/'AssetManifest.csv'
        rows=read_csv(mp) if mp.exists() else []
        manifests[v]=rows
        for r in rows:
            ep=r.get('export_path') or ''
            if ep: exp_index[(v,Path(ep).name)]=r
        for p in (root/'Texture2D').glob('*.png') if (root/'Texture2D').exists() else []:
            m=HASH_RE.search(p.name)
            if m:texture_by_hash[(v,m.group(1).lower())].append(p)

    rows=read_csv(map_csv)
    recovered=0; failures=[]; provenance=[]
    for r in rows:
        if r.get('status')!='missing':continue
        expected=r.get('expected','')
        m=HASH_RE.search(expected)
        if not m:continue
        guid=m.group(1).lower()
        # mapping's expected hashed assets belong to 0.22.21 in this package; still probe both.
        choices=[]
        for v,_root in versions:
            mr=exp_index.get((v,expected))
            if mr and mr.get('class_name')=='Sprite': choices.append((v,mr))
        if not choices:continue
        done=False
        for v,mr in choices:
            texs=texture_by_hash.get((v,guid),[])
            if not texs:continue
            rect=parse_vec(mr.get('rect'))
            tight=parse_vec(mr.get('texture_rect')) or rect
            off=parse_vec(mr.get('texture_rect_offset')) or [0.0,0.0]
            if not rect or not tight or len(rect)<4 or len(tight)<4:continue
            tex=texs[0]
            try:
                im=Image.open(tex).convert('RGBA')
                x,y,w,h=tight[:4]
                # Unity Sprite rect uses bottom-left origin; PIL uses top-left.
                left=max(0,int(math.floor(x))); right=min(im.width,int(math.ceil(x+w)))
                bottom=max(0,int(math.floor(y))); top=min(im.height,int(math.ceil(y+h)))
                if right<=left or top<=bottom:raise ValueError('empty crop')
                crop=im.crop((left,im.height-top,right,im.height-bottom))
                cw=max(1,int(round(rect[2]))); ch=max(1,int(round(rect[3])))
                canvas=Image.new('RGBA',(cw,ch),(0,0,0,0))
                ox=max(0,int(round(off[0]))); oy=max(0,int(round(off[1])))
                # offset is from sprite rect bottom-left; translate to PIL top-left.
                paste_y=max(0,ch-oy-crop.height)
                canvas.paste(crop,(ox,paste_y),crop)
                out=art/expected
                canvas.save(out,optimize=False)
                r['actual']='project/恢复_图集拆帧/'+expected
                r['status']='reconstructed_from_atlas'
                recovered+=1;done=True
                provenance.append({
                    'resource':r.get('resource',''),'expected':expected,'output':str(out.relative_to(project)),
                    'source_texture':str(tex.relative_to(source)),'source_texture_sha256':sha256(tex),
                    'manifest_version':v,'rect':mr.get('rect'),'texture_rect':mr.get('texture_rect'),
                    'texture_rect_offset':mr.get('texture_rect_offset'),'output_sha256':sha256(out)
                })
                break
            except Exception as e:
                failures.append({'expected':expected,'texture':str(tex),'error':str(e)})
        if not done and choices:
            failures.append({'expected':expected,'error':'manifest sprite found but matching physical texture was unavailable'})

    # Second pass: old 0.9.0 sprites use resources.assets path ids rather than content hashes.
    old_root=dict(versions).get('0.9.0原版')
    old_rows=manifests.get('0.9.0原版',[])
    old_by_exp={Path(x.get('export_path') or '').name:x for x in old_rows if x.get('export_path')}
    old_tex_by_ref={(x.get('source_file',''),x.get('path_id','')):x for x in old_rows if x.get('class_name')=='Texture2D'}
    for r in rows:
        if r.get('status')!='missing':continue
        expected=r.get('expected',''); mr=old_by_exp.get(expected)
        if not mr or mr.get('class_name')!='Sprite':continue
        nums=re.findall(r'-?\d+',mr.get('texture',''))
        if not nums or nums[-1]=='0':continue
        tr=old_tex_by_ref.get((mr.get('source_file',''),nums[-1]))
        if not tr or not tr.get('export_path'):continue
        tex=old_root/tr['export_path']
        if not tex.exists():continue
        rect=parse_vec(mr.get('rect')); tight=parse_vec(mr.get('texture_rect')) or rect; off=parse_vec(mr.get('texture_rect_offset')) or [0.0,0.0]
        if not rect or not tight or len(rect)<4 or len(tight)<4:continue
        try:
            im=Image.open(tex).convert('RGBA'); x,y,w,h=tight[:4]
            left=max(0,int(math.floor(x))); right=min(im.width,int(math.ceil(x+w)))
            bottom=max(0,int(math.floor(y))); top=min(im.height,int(math.ceil(y+h)))
            if right<=left or top<=bottom:raise ValueError('empty crop')
            crop=im.crop((left,im.height-top,right,im.height-bottom))
            cw=max(1,int(round(rect[2]))); ch=max(1,int(round(rect[3])))
            canvas=Image.new('RGBA',(cw,ch),(0,0,0,0)); ox=max(0,int(round(off[0]))); oy=max(0,int(round(off[1])))
            canvas.paste(crop,(ox,max(0,ch-oy-crop.height)),crop)
            out=art/expected; canvas.save(out,optimize=False)
            r['actual']='project/恢复_图集拆帧/'+expected; r['status']='reconstructed_from_atlas'; recovered+=1
            provenance.append({'resource':r.get('resource',''),'expected':expected,'output':str(out.relative_to(project)),'source_texture':str(tex.relative_to(source)),'source_texture_sha256':sha256(tex),'manifest_version':'0.9.0原版','rect':mr.get('rect'),'texture_rect':mr.get('texture_rect'),'texture_rect_offset':mr.get('texture_rect_offset'),'output_sha256':sha256(out)})
        except Exception as e: failures.append({'expected':expected,'texture':str(tex),'error':str(e)})

    # Third pass: a small set of 0.9.0 Sprite entries lost their texture pointer as [0,0],
    # but their semantic atlas is unambiguous from the original resource family.  Recover only
    # those whitelisted families and only when the recorded rect fits the real named atlas.
    known_atlas={
      'grass':'tiles__resources.assets__107.png','grass_flowers':'tiles__resources.assets__107.png',
      'mountains':'tiles__resources.assets__107.png','mountains_frozen':'tiles__resources.assets__107.png',
      'road':'tiles__resources.assets__107.png','sand':'tiles__resources.assets__107.png',
      'sand_creep':'tiles__resources.assets__107.png','sand_frozen':'tiles__resources.assets__107.png',
      'shallow_waters':'tiles__resources.assets__107.png','shallow_waters_frozen':'tiles__resources.assets__107.png',
      'pit_shallow_waters':'tiles__resources.assets__107.png','border_water':'tiles__resources.assets__107.png',
      't_bandit_heads':'t_bandit_heads__resources.assets__34.png',
      't_demon_heads':'t_demon_heads__resources.assets__1004.png',
      't_walker_heads':'t_walker_heads__resources.assets__985.png',
    }
    def family(name):
        for k in sorted(known_atlas,key=len,reverse=True):
            if name==k or name.startswith(k+'_') or name.startswith(k+'#'): return k
        return None
    for r in rows:
        if r.get('status')!='missing':continue
        fam=family(r.get('resource',''))
        if not fam:continue
        expected=r.get('expected',''); mr=old_by_exp.get(expected)
        if not mr or mr.get('class_name')!='Sprite':continue
        rect=parse_vec(mr.get('rect')); tight=parse_vec(mr.get('texture_rect')) or rect; off=parse_vec(mr.get('texture_rect_offset')) or [0.0,0.0]
        tex=old_root/'Texture2D'/known_atlas[fam]
        if not tex.exists() or not rect or not tight:continue
        try:
            im=Image.open(tex).convert('RGBA'); x,y,w,h=tight[:4]
            left=max(0,int(math.floor(x))); right=min(im.width,int(math.ceil(x+w)))
            bottom=max(0,int(math.floor(y))); top=min(im.height,int(math.ceil(y+h)))
            if right<=left or top<=bottom:raise ValueError('rect outside known atlas')
            crop=im.crop((left,im.height-top,right,im.height-bottom))
            cw=max(1,int(round(rect[2]))); ch=max(1,int(round(rect[3])))
            canvas=Image.new('RGBA',(cw,ch),(0,0,0,0)); ox=max(0,int(round(off[0]))); oy=max(0,int(round(off[1])))
            canvas.paste(crop,(ox,max(0,ch-oy-crop.height)),crop)
            out=art/expected; canvas.save(out,optimize=False)
            r['actual']='project/恢复_图集拆帧/'+expected; r['status']='reconstructed_from_known_atlas'; recovered+=1
            provenance.append({'resource':r.get('resource',''),'expected':expected,'output':str(out.relative_to(project)),'source_texture':str(tex.relative_to(source)),'source_texture_sha256':sha256(tex),'manifest_version':'0.9.0原版','recovery_rule':'known_atlas:'+fam,'rect':mr.get('rect'),'texture_rect':mr.get('texture_rect'),'texture_rect_offset':mr.get('texture_rect_offset'),'output_sha256':sha256(out)})
        except Exception as e: failures.append({'expected':expected,'texture':str(tex),'error':str(e)})


    # Fourth pass: recover 0.9.0 sprites packed inside SpriteAtlas.  These Sprite rows
    # intentionally have texture=[0,0]; the actual Texture2D path and packed rectangle live
    # in SpriteAtlas render data keyed by render_key_guid + render_key_id.  Parse the raw
    # WorldAtlas object instead of guessing by filename.
    old_json_path=old_root/'AssetManifest.json' if old_root else None
    old_json=[]
    if old_json_path and old_json_path.exists():
        try: old_json=json.loads(old_json_path.read_text(encoding='utf-8'))
        except Exception: old_json=[]
    old_sprites_by_name=defaultdict(list)
    old_tex_by_pid={}
    for x in old_json:
        if x.get('status')!='png': continue
        if x.get('class_name')=='Sprite' and x.get('name'):
            old_sprites_by_name[x['name']].append(x)
        elif x.get('class_name')=='Texture2D' and x.get('path_id') is not None:
            old_tex_by_pid[(x.get('source_file',''),int(x.get('path_id')))] = x
    atlas_bin=old_root/'其他命名对象原始块/SpriteAtlas/WorldAtlas__resources.assets__19730.bin' if old_root else None
    atlas_bytes=atlas_bin.read_bytes() if atlas_bin and atlas_bin.exists() else b''

    def atlas_render_data(sprite):
        guid=(sprite.get('render_key_guid') or '').strip()
        rid=sprite.get('render_key_id')
        if len(guid)!=32 or rid is None or not atlas_bytes:return None
        try:g=bytes.fromhex(guid); rid=int(rid)
        except Exception:return None
        start=0
        while True:
            pos=atlas_bytes.find(g,start)
            if pos<0:return None
            # SpriteRenderDataKey = Hash128 (16) + int64. SpriteAtlasData then starts
            # with two PPtrs (12 bytes each), followed by Rectf and textureRectOffset.
            if pos+72<=len(atlas_bytes):
                try:
                    key_id=int.from_bytes(atlas_bytes[pos+16:pos+24],'little',signed=True)
                    if key_id==rid:
                        tex_file=int.from_bytes(atlas_bytes[pos+24:pos+28],'little',signed=True)
                        tex_pid=int.from_bytes(atlas_bytes[pos+28:pos+36],'little',signed=True)
                        import struct
                        packed_rect=list(struct.unpack_from('<ffff',atlas_bytes,pos+48))
                        packed_off=list(struct.unpack_from('<ff',atlas_bytes,pos+64))
                        return {'offset':pos,'texture_file_id':tex_file,'texture_path_id':tex_pid,'packed_rect':packed_rect,'texture_rect_offset':packed_off}
                except Exception: pass
            start=pos+1

    for r in rows:
        if r.get('status') not in ('missing','reconstructed_from_spriteatlas'):continue
        was_missing=(r.get('status')=='missing')
        name=r.get('resource',''); expected=r.get('expected','')
        candidates=list(old_sprites_by_name.get(name,[]))
        if not candidates:continue
        hm=HASH_RE.search(expected)
        target_guid=nibble_swap_hash(hm.group(1)) if hm else ''
        if target_guid:
            candidates.sort(key=lambda x: 0 if (x.get('render_key_guid') or '').lower()==target_guid else 1)
        restored=False
        for mr in candidates:
            atlas_ref=mr.get('atlas') or [0,0]
            if not isinstance(atlas_ref,list) or len(atlas_ref)<2 or int(atlas_ref[-1] or 0)!=19730:continue
            rd=atlas_render_data(mr)
            if not rd or rd['texture_path_id']<=0:continue
            tr=old_tex_by_pid.get(('resources.assets',rd['texture_path_id']))
            if not tr or not tr.get('export_path'):continue
            tex=old_root/tr['export_path']
            if not tex.exists():continue
            logical_rect=mr.get('rect') or rd['packed_rect']
            try:
                rect=[float(x) for x in logical_rect]
                x,y,w,h=[float(x) for x in rd['packed_rect']]
                im=Image.open(tex).convert('RGBA')
                left=max(0,int(math.floor(x))); right=min(im.width,int(math.ceil(x+w)))
                bottom=max(0,int(math.floor(y))); top=min(im.height,int(math.ceil(y+h)))
                if right<=left or top<=bottom:raise ValueError('atlas packed rect outside texture')
                crop=im.crop((left,im.height-top,right,im.height-bottom))
                cw=max(1,int(round(rect[2]))); ch=max(1,int(round(rect[3])))
                canvas=Image.new('RGBA',(cw,ch),(0,0,0,0))
                ox=max(0,int(round(rd['texture_rect_offset'][0]))); oy=max(0,int(round(rd['texture_rect_offset'][1])))
                canvas.paste(crop,(ox,max(0,ch-oy-crop.height)),crop)
                out=art/expected; canvas.save(out,optimize=False)
                r['actual']='project/恢复_图集拆帧/'+expected
                r['status']='reconstructed_from_spriteatlas'
                if was_missing: recovered+=1
                restored=True
                provenance.append({
                    'resource':name,'expected':expected,'output':str(out.relative_to(project)),
                    'source_texture':str(tex.relative_to(source)),'source_texture_sha256':sha256(tex),
                    'manifest_version':'0.9.0原版','recovery_rule':'spriteatlas_render_key',
                    'sprite_path_id':mr.get('path_id'),'render_key_guid':mr.get('render_key_guid'),
                    'render_key_id':mr.get('render_key_id'),'atlas_path_id':19730,
                    'atlas_texture_path_id':rd['texture_path_id'],'atlas_binary_offset':rd['offset'],
                    'logical_rect':rect,'packed_rect':rd['packed_rect'],
                    'texture_rect_offset':rd['texture_rect_offset'],'output_sha256':sha256(out)
                })
                break
            except Exception as e:
                failures.append({'expected':expected,'resource':name,'error':'spriteatlas:'+str(e)})
        if restored:continue


    # Fifth pass: reconstruct complete strip textures from their original SpriteAtlas frames.
    # This is valid only when the expected hash maps to a single render-key family and the
    # original Texture2D dimensions are known from the manifest.  Pixels come from the real
    # atlas; the strip is assembled at each Sprite's original rect.
    def render_atlas_sprite(mr):
        rd=atlas_render_data(mr)
        if not rd or rd['texture_path_id']<=0:return None,None
        tr=old_tex_by_pid.get(('resources.assets',rd['texture_path_id']))
        if not tr or not tr.get('export_path'):return None,None
        tex=old_root/tr['export_path']
        if not tex.exists():return None,None
        rect=[float(x) for x in (mr.get('rect') or rd['packed_rect'])]
        x,y,w,h=[float(x) for x in rd['packed_rect']]
        im=Image.open(tex).convert('RGBA')
        left=max(0,int(math.floor(x))); right=min(im.width,int(math.ceil(x+w)))
        bottom=max(0,int(math.floor(y))); top=min(im.height,int(math.ceil(y+h)))
        if right<=left or top<=bottom:return None,None
        crop=im.crop((left,im.height-top,right,im.height-bottom))
        cw=max(1,int(round(rect[2]))); ch=max(1,int(round(rect[3])))
        frame=Image.new('RGBA',(cw,ch),(0,0,0,0))
        ox=max(0,int(round(rd['texture_rect_offset'][0]))); oy=max(0,int(round(rd['texture_rect_offset'][1])))
        frame.paste(crop,(ox,max(0,ch-oy-crop.height)),crop)
        return frame,{'source_texture':tex,'render_data':rd,'logical_rect':rect}

    for r in rows:
        if r.get('status')!='missing':continue
        base=r.get('resource',''); expected=r.get('expected','')
        hm=HASH_RE.search(expected)
        target_guid=nibble_swap_hash(hm.group(1)) if hm else ''
        if not target_guid:continue
        tex_defs=old_sprites_by_name  # keep a readable name for provenance below
        old_texture_defs=[x for x in old_json if x.get('class_name')=='Texture2D' and x.get('status')=='png' and x.get('name')==base]
        if not old_texture_defs:continue
        tw=int(old_texture_defs[0].get('width') or 0); th=int(old_texture_defs[0].get('height') or 0)
        if tw<=0 or th<=0:continue
        frames=[]
        frame_prefix='hit' if base=='hitCritical' else base
        for nm,cands in old_sprites_by_name.items():
            if not re.fullmatch(re.escape(frame_prefix)+r'_\d+',nm):continue
            for mr in cands:
                if (mr.get('render_key_guid') or '').lower()!=target_guid:continue
                frame,meta=render_atlas_sprite(mr)
                if frame is not None:frames.append((mr,frame,meta))
                break
        if not frames:continue
        canvas=Image.new('RGBA',(tw,th),(0,0,0,0))
        used=[]
        for mr,frame,meta in frames:
            lr=[float(x) for x in mr.get('rect')]
            px=int(round(lr[0])); py=int(round(lr[1]))
            canvas.paste(frame,(px,max(0,th-py-frame.height)),frame)
            used.append({'sprite':mr.get('name'),'sprite_path_id':mr.get('path_id'),'rect':lr,'atlas_texture_path_id':meta['render_data']['texture_path_id'],'packed_rect':meta['render_data']['packed_rect']})
        out=art/expected; canvas.save(out,optimize=False)
        r['actual']='project/恢复_图集拆帧/'+expected; r['status']='reconstructed_from_sprite_frames'; recovered+=1
        provenance.append({'resource':base,'expected':expected,'output':str(out.relative_to(project)),'manifest_version':'0.9.0原版','recovery_rule':'rebuild_texture_from_spriteatlas_frames','render_key_guid':target_guid,'texture_size':[tw,th],'frames':used,'output_sha256':sha256(out)})

    with open(map_csv,'w',encoding='utf-8-sig',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=['resource','expected','actual','status']);wr.writeheader();wr.writerows(rows)
    counts=Counter(r['status'] for r in rows)
    pngs=list((project/'Assets/Resources/LordWarArt').rglob('*.png'))
    report={
        'mapping_rows':len(rows),'exact':counts['exact'],'logical_substitute':counts['logical_substitute'],
        'reconstructed_from_atlas':counts['reconstructed_from_atlas'],'reconstructed_from_known_atlas':counts['reconstructed_from_known_atlas'],'reconstructed_from_spriteatlas':counts['reconstructed_from_spriteatlas'],'reconstructed_from_sprite_frames':counts['reconstructed_from_sprite_frames'],'atlas_source':counts['atlas_source'],
        'missing':counts['missing'],
        'resolved_total':len(rows)-counts['missing'],
        'unique_imported_png':len(pngs),
        'custom_v20_png':sum(1 for p in pngs if 'V20新增' in str(p)),
        'total_bytes':sum(p.stat().st_size for p in pngs),
        'missing_sample':[{'resource':r['resource'],'expected':r['expected'],'status':'missing'} for r in rows if r['status']=='missing'][:80],
        'note':'reconstructed_from_atlas 表示依据真实Unity AssetManifest Sprite矩形从同GUID真实Texture2D图集恢复，并非原导出PNG逐字节精确文件。'
    }
    (evidence/'ASSET_IMPORT_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (evidence/'ATLAS_RECOVERY_PROVENANCE.json').write_text(json.dumps({'recovered_this_run':recovered,'items':provenance,'failures':failures[:200]},ensure_ascii=False,indent=2),encoding='utf-8')
    with open(evidence/'RECOVERED_ASSET_SHA256.csv','w',encoding='utf-8-sig',newline='') as f:
        wr=csv.writer(f);wr.writerow(['path','sha256','bytes'])
        for p in sorted(art.glob('*.png')):wr.writerow([str(p.relative_to(project)),sha256(p),p.stat().st_size])
    print(json.dumps({'recovered_this_run':recovered,'counts':counts,'png_count':len(pngs),'failures':len(failures)},ensure_ascii=False))

if __name__=='__main__': main()
