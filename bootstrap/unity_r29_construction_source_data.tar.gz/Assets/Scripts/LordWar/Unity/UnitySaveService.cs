#if UNITY_5_3_OR_NEWER
using System;
using System.IO;
using UnityEngine;
using LordWar.Save;
using LordWar.Simulation;
namespace LordWar.UnityRuntime {
 public static class UnitySaveService {
  public static string SavePath{get{return Path.Combine(Application.persistentDataPath,"lordwar_save.json");}}
  static string BackupPath{get{return SavePath+".bak";}}
  static string TempPath{get{return SavePath+".tmp";}}
  static string LegacyPath{get{return Path.Combine(Application.persistentDataPath,"lordwar_save_v7.json");}}
  public static bool Save(GameWorld w){if(w==null)return false;try{GameSave data=GameSaveService.Capture(w);string error;if(!GameSaveService.Validate(data,out error)){Debug.LogError("存档前校验失败："+error);return false;}string json=JsonUtility.ToJson(data,true);File.WriteAllText(TempPath,json,System.Text.Encoding.UTF8);GameSave verify=JsonUtility.FromJson<GameSave>(File.ReadAllText(TempPath,System.Text.Encoding.UTF8));if(!GameSaveService.Validate(verify,out error)){Debug.LogError("存档回读校验失败："+error);return false;}if(File.Exists(SavePath)){try{File.Replace(TempPath,SavePath,BackupPath,true);}catch{File.Copy(SavePath,BackupPath,true);File.Copy(TempPath,SavePath,true);File.Delete(TempPath);}}else{File.Move(TempPath,SavePath);}return File.Exists(SavePath);}catch(Exception e){Debug.LogError("保存失败："+e.Message);return false;}}
  public static bool Load(GameWorld w){if(w==null)return false;string[] candidates={SavePath,BackupPath,LegacyPath};for(int i=0;i<candidates.Length;i++){string path=candidates[i];if(!File.Exists(path))continue;try{string json=File.ReadAllText(path,System.Text.Encoding.UTF8);GameSave data=JsonUtility.FromJson<GameSave>(json);string error;if(!GameSaveService.Validate(data,out error)){Debug.LogWarning("存档不可用："+path+" / "+error);continue;}GameSaveService.Restore(w,data);return true;}catch(Exception e){Debug.LogWarning("读取存档失败："+path+" / "+e.Message);}}return false;}
 }
}
#endif
