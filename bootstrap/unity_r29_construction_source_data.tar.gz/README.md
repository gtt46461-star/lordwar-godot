# 领主战争 V9 真实施工工程

这是从V9冻结总包恢复的新Unity工程骨架。母体反编译源码只作为结构/素材参考，不冒充原Unity工程。
核心运行链位于 `Assets/Scripts/LordWar`，正式数据位于 `Assets/Resources/LordWarData`。
